let counter =0;

let result = document.querySelector('#result');
let reset = document.querySelector('.reset');
let add = document.querySelector('.add');
let sub = document.querySelector('.sub');

reset.addEventListener('click',(e)=>{
  counter = 0;
  result.innerText = counter;
});

add.addEventListener('click',(e)=>{
  counter++;
  result.innerText = counter;
});

sub.addEventListener('click',(e)=>{
  
  if (counter === 0) {
    counter = 0;
    return 0;
  }
  counter--;
  result.innerText = counter;
  
})